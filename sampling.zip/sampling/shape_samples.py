import os 
import random 

# read airfoils names
namelist =[]
f = open('first_set.txt','r')
while True:
  filename=f.readline()
  if filename:
    namelist.append(filename.rstrip())
  else:
    break
f.close()

def sample_shapes(names, num_samples):
	if num_samples > len(names):
		num_samples = len(names)
		
	sampled_shapes = random.sample(names, num_samples)
	return sampled_shapes

original_list= len(namelist)
unsaved = namelist
saved_shapes = []
i=1
while len(saved_shapes) < original_list and i<40:

	
	print(len(unsaved))
	filename = "set" + str(i) + ".txt"
	
	sampled_shapes = sample_shapes(unsaved, 10)
	  
	with open(filename, 'w') as file:
		for shape in sampled_shapes:
			file.write(shape + '\n')
					
			
	f = open(filename,'r')
	while True:
	  filename=f.readline()
	  if filename:
	    saved_shapes.append(filename.rstrip())
	  else:
	    break
	f.close()
	
	unsaved = list(set(namelist) - set(saved_shapes))
	
	i += 1
