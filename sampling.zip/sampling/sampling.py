from prefoil import Airfoil, sampling
from prefoil.utils import readCoordFile
import matplotlib.pyplot as plt
import numpy as np
import os 
import math


# read airfoils names
namelist =[]
f = open('step3_name.txt','r')
while True:
  filename=f.readline()
  if filename:
    namelist.append(filename.rstrip())
  else:
    break
f.close()
print(len(namelist))

os.system('mkdir test_sampled')

for iair in range(len(namelist)):
	filename = 'picked_uiuc/' + namelist[iair]
	coords = readCoordFile(filename)
	airfoil = Airfoil(coords)
	
	# Sample with a cosine on the upper surface and on the lower surface
	coords = airfoil.getSampledPts(
	    22, spacingFunc=[sampling.cosine, sampling.cosine])
	# print(type(coords)) #it is a numpay.array
	y_coordinates= coords[:,1].copy()
	namelist[iair]= namelist[iair].replace('.dat','.npy')

	np.save('test_sampled/' + namelist[iair], coords)

		
	
		
